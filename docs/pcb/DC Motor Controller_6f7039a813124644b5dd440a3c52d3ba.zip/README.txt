<p>- 8-36V, 20A continuous, 40A peak</p>
<p>- Adjustable cycle by cycle motor current limit (0.5-40A)</p>
<p>- Adjustable max. current with signal LED (0.5-40A)</p>
<p>- 1.14" 135x240 TFT display, rotary encoder and 3 buttons for easy navigation</p>
<p>- Support for magnetic encoder MT6701 in A/B mode up to 1024PPR (55000 RPM)</p>
<p>- Dimmable LED with CC driver 3-26V/350mA/5W</p>
<p>- Current, voltage and temperature monitoring</p>
<p> </p>
<p>Firmware: https://github.com/sascha432/motor_controller_stm32</p>            
How to use：

At editor, open the document via: Top menu - File - Open - EasyEDA... , and select the json file, then open it at the editor, you can save it into a project.


如何使用：

打开编辑器，通过：顶部菜单 - 文件 - 打开 - 立创EDA... ，选择 json 文件打开在编辑器，你可以保存文档进工程里面。